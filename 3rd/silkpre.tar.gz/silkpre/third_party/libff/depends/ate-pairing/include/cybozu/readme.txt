see
https://github.com/herumi/cybozulib/
