# Implementation of altbn128

## Run the sage script to generate the curve parameters

1. Make sure that you have [SageMath](https://www.sagemath.org/) installed

2. Run:
```bash
sage alt_bn128.sage
```
